export default () => ({
  // ... other config
  CRYPTOCOMPARE_API_KEY: process.env.CRYPTOCOMPARE_API_KEY,
}); 