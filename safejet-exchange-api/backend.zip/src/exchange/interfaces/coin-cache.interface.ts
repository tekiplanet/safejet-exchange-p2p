export interface CoinCache {
  id: string;
  lastUpdated: Date;
} 