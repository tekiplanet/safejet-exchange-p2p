export class CreateWalletEvent {
  constructor(public readonly userId: string) {}
} 