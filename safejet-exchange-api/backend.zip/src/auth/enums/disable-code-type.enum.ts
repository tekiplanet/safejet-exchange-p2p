export enum DisableCodeType {
  AUTHENTICATOR = 'authenticator',
  BACKUP = 'backup',
}
